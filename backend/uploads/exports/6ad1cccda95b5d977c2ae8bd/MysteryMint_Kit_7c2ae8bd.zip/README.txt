
MysteryMint AI — Murder
==================================================

Genre:      Murder Mystery
Setting:    Luxury Hotel
Difficulty: Medium
Players:    4 - 8
Duration:   60 minutes
Audience:   Adults

Generated:  10/16/2026, 12:59:31 PM

------------------------------------------------------------
WHAT'S INSIDE
------------------------------------------------------------

Player_Kit/
  • Mystery_Story.pdf          — The full story & introduction
  • Suspect_Cards.pdf          — Character profiles
  • Clues_and_Evidence.pdf     — Clues and evidence documents
  • Puzzle_Sheets.pdf          — Ciphers, riddles, logic puzzles
  • Player_Instructions.pdf    — Setup rules & timeline

Game_Master/
  • Solution_Guide.pdf         — Culprit, motive, method & answers

Images/
  • Mystery_Cover.png          — Cover illustration
  • Characters/                — Character portraits
  • Crime_Scenes/              — Scene illustrations

------------------------------------------------------------
HOW TO PLAY
------------------------------------------------------------

1. Read Player_Instructions.pdf first.
2. Print Suspect_Cards.pdf for each player.
3. Read Mystery_Story.pdf aloud.
4. Distribute Clues_and_Evidence.pdf and Puzzle_Sheets.pdf.
5. Only the Game Master should read Game_Master/Solution_Guide.pdf
   — and only after the investigation concludes.

Enjoy your mystery.

— MysteryMint AI
