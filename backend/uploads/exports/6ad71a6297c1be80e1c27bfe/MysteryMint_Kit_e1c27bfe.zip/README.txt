
MysteryMint AI — Midnight Executive Skyline
==================================================

Genre:      Detective Mystery
Setting:    Luxury Skyscraper Penthouse
Difficulty: Medium
Players:    4 - 8
Duration:   90 minutes
Audience:   Adults

Generated:  10/20/2026, 1:43:00 PM

------------------------------------------------------------
WHAT'S INSIDE
------------------------------------------------------------

Player_Kit/
  • Mystery_Story.pdf
  • Suspect_Cards.pdf
  • Clues_and_Evidence.pdf
  • Puzzle_Sheets.pdf
  • Player_Instructions.pdf

Game_Master/
  • Solution_Guide.pdf

Images/
  • Mystery_Cover.png
  • Characters/
  • Crime_Scenes/

------------------------------------------------------------
HOW TO PLAY
------------------------------------------------------------

1. Read Player_Instructions.pdf first.
2. Print Suspect_Cards.pdf for each player.
3. Read Mystery_Story.pdf aloud.
4. Distribute Clues_and_Evidence.pdf and Puzzle_Sheets.pdf.
5. Only the Game Master should read Game_Master/Solution_Guide.pdf.

Enjoy your mystery.
— MysteryMint AI
