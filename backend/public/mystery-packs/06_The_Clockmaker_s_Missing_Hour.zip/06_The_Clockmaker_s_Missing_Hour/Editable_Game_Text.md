# The Clockmaker's Missing Hour


## Case briefing

The Clockmaker's Missing Hour
A clockmaker's prototype escapement disappears during a public demonstration. The workshop clock appears to give the thief an alibi, but it was one hour slow. Find the mechanism and the person who took it.

Your mission
Identify the responsible person, explain the method and recover the missing item or recording. Cite at least two independent pieces of evidence.

Session details
Workshop mystery | Ages 12+ | 1-6 investigators | 35-60 minutes | No graphic violence

Rules and preparation
Play cooperatively as investigators; suspects are case documents, not assigned player roles. Use a pen and paper. A host is optional. Keep Host Guide.pdf closed. Read this booklet in order. All evidence is truthful; suspect statements may be false. Do not invent accomplices, copied credentials or unseen events contrary to the stated rules.

## Suspect dossiers

Greta Finch, apprentice
Possible motive: She wants recognition for helping design it.
Statement: "I left before the demonstration."

Hugo Bell, collector
Possible motive: He wants the unique mechanism for his collection.
Statement: "I was never inside the prototype room."

Lina Shaw, archivist
Possible motive: The sale would scatter the workshop archive.
Statement: "I catalogued papers all afternoon."

Marco Flint, delivery clerk
Possible motive: He is owed delivery fees.
Statement: "I stayed at the loading door."

## Evidence: access and timeline

Incident window
mechanism removed at 15:10 verified town time.

Operating rules
Town-clock photographs and the delivery scanner use verified time. The workshop clock is exactly one hour slow, never fast.

Evidence E1
Workshop camera shows Hugo entering the prototype room at displayed 14:09 and leaving at displayed 14:12.

Evidence E2
A town-clock photo places Greta outside at 15:10. Lina and Marco appear on the loading camera at 15:10.

Evidence E3
The prototype pressure sensor records removal at verified 15:10.

## Evidence: follow the trail

Evidence E4
Hugo's collection case inventory has a newly added compartment labelled by three clock faces.

Evidence E5
Faces show 3 o'clock, 9 o'clock, 6 o'clock, in that order.

Recovery puzzle
Read the hour hand on the three faces: 3, 9, 6. Use the digits in order for the case code. Also convert workshop 14:10 to town time.

Investigation task
Compare statements to records. Which statement is contradicted? Which records exclude the other suspects? Solve the recovery clue before making an accusation. The recovery clue locates the item; it does not alone identify who hid it.

## Investigator worksheet

1 / Reconstruction
At the incident time, where was each suspect? Write a short timeline and attach evidence numbers.

2 / Contradiction
Quote the statement that conflicts with a reliable record. Explain why the record is reliable under the operating rules.

3 / Recovery
Puzzle answer: ______________________________
Expected recovery location: ______________________________

4 / Final accusation
Responsible person: ______________________________
Method: __________________________________________
Evidence one: ______________________________________
Evidence two: ______________________________________

5 / Alternative explanation
Name one suspicious fact that does not prove guilt. Explain why it does not overturn your conclusion.

Submit your solution
After everyone agrees, open the Host Guide. Award points using its rubric. You may revise your answer before reading the solution.

## Host setup and running order

Keep this file separate
SPOILERS. Give players only Player Booklet.pdf and the cover. In solo play, close this guide until you need a hint or wish to check your answer.

Before play
Print the five-page player booklet at 100% on A4, or share the PDF digitally. Provide pens and paper. No internet, external research, locks or special props are required. For groups, appoint a reader, timeline keeper and evidence reviewer; combine roles for smaller groups.

Suggested session
0-5 min: briefing and rules. 5-15 min: suspects. 15-30 min: evidence and recovery puzzle. 30-45 min: debate and worksheet. 45-60 min: hints if needed, reveal and discussion. These are suggested timings, not a mandatory timer.

Reveal procedure
Do not reveal the hiding place during setup. Once players submit an accusation, narrate finding the item at the location in the answer key. No physical search is required; the entire recovery is a paper puzzle.

Facilitation
Read only the written statements. Do not improvise extra alibis. If players propose credential theft or hidden conspirators, direct them to the operating rules. Let them challenge interpretations of evidence.

## Progressive hints

Hint 1 / direction
Separate motive from proof. Start with the exact incident window and the rules that make the access or camera record trustworthy.

Hint 2 / elimination
Compare all four statements against E1-E4. Locate the suspect whose claimed whereabouts or denied action cannot match the records. Check the other three people at that same time.

Hint 3 / recovery
Read the hour hand on the three faces: 3, 9, 6. Use the digits in order for the case code. Also convert workshop 14:10 to town time.
Work only with the supplied alphabet, key, fragments or directions; no external knowledge is required.

Hint 4 / strong hint
The record that directly connects Hugo Bell to the incident is decisive. The recovery answer is 396; town time 15:10.

Hint policy
Offer hints one at a time and only on request. Hints 1-3 cost one point each. Hint 4 costs two points. Floor the final score at zero.

## Solution and evidence chain

Responsible person
Hugo Bell, collector.

Method
Hugo removed the escapement at real 15:10 and relied on the slow workshop clock to make his visit seem earlier.

Decisive chain
E1-E3 establish the relevant access, identity or timing. E4 adds corroboration or excludes another explanation. Compare these facts with the suspect statements; do not convict solely on motive.

Recovery answer
396; town time 15:10. The item is found at compartment 396 in Hugo's collection case.

Red herring explained
Greta disputes credit for the invention, but her timed town photograph places her outside during the removal.

Score / 10
2 points: correct person. 2: correct method. 2: two valid evidence references, one each. 2: correct recovery answer and location. 2: explain a red herring or eliminate an alternative. Subtract hint costs. 8-10: Case closed; 5-7: Strong lead; 0-4: Revisit the evidence.

Debrief
Which fact was necessary to your conclusion? Which suspect statement was unreliable? Why does motive alone fail to prove responsibility? All characters, events and institutions are fictional.
