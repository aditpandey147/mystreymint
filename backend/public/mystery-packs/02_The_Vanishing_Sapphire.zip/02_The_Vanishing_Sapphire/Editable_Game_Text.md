# The Vanishing Sapphire


## Case briefing

The Vanishing Sapphire
The Tide Sapphire vanishes during a museum lighting rehearsal. Four staff members were inside, but the jewel cabinet records only one authenticated opening. Find the stone before the gala.

Your mission
Identify the responsible person, explain the method and recover the missing item or recording. Cite at least two independent pieces of evidence.

Session details
Museum heist | Ages 12+ | 1-6 investigators | 35-60 minutes | No graphic violence

Rules and preparation
Play cooperatively as investigators; suspects are case documents, not assigned player roles. Use a pen and paper. A host is optional. Keep Host Guide.pdf closed. Read this booklet in order. All evidence is truthful; suspect statements may be false. Do not invent accomplices, copied credentials or unseen events contrary to the stated rules.

## Suspect dossiers

Iris Chen, curator
Possible motive: An exhibition failure could end her career.
Statement: "I was in the lobby during the blackout."

Leo March, lighting engineer
Possible motive: He owes a large equipment bill.
Statement: "I ran the lighting desk all evening."

Nadia Sol, gem conservator
Possible motive: A private buyer offered her a fortune.
Statement: "I never opened the sapphire cabinet tonight."

Felix Ward, sponsor liaison
Possible motive: The sponsor wants the gala cancelled.
Statement: "I stayed at reception."

## Evidence: access and timeline

Incident window
stone removed at 20:14.

Operating rules
Cabinet openings require a registered fingerprint plus a personal badge. The audit confirms no override or spoofing.

Evidence E1
20:14 cabinet opened by conservator badge C3 and matching fingerprint.

Evidence E2
Badge registry: Iris C1; Leo C2; Nadia C3; Felix C4.

Evidence E3
Lobby footage shows Iris and Felix together at 20:14. Leo is visible at the lighting desk.

## Evidence: follow the trail

Evidence E4
A padded transport tube was checked into restoration storage at 20:18 by C3.

Evidence E5
Storage instruction: read only the capital letters in the next message: leaVe, wAit, hUsh, sLow, resT.

Recovery puzzle
Extract the capitals from: leaVe, wAit, hUsh, sLow, resT. Which storage area do they spell? Storage map: VAULT is the transport archive; other areas are LAB and OFFICE.

Investigation task
Compare statements to records. Which statement is contradicted? Which records exclude the other suspects? Solve the recovery clue before making an accusation. The recovery clue locates the item; it does not alone identify who hid it.

## Investigator worksheet

1 / Reconstruction
At the incident time, where was each suspect? Write a short timeline and attach evidence numbers.

2 / Contradiction
Quote the statement that conflicts with a reliable record. Explain why the record is reliable under the operating rules.

3 / Recovery
Puzzle answer: ______________________________
Expected recovery location: ______________________________

4 / Final accusation
Responsible person: ______________________________
Method: __________________________________________
Evidence one: ______________________________________
Evidence two: ______________________________________

5 / Alternative explanation
Name one suspicious fact that does not prove guilt. Explain why it does not overturn your conclusion.

Submit your solution
After everyone agrees, open the Host Guide. Award points using its rubric. You may revise your answer before reading the solution.

## Host setup and running order

Keep this file separate
SPOILERS. Give players only Player Booklet.pdf and the cover. In solo play, close this guide until you need a hint or wish to check your answer.

Before play
Print the five-page player booklet at 100% on A4, or share the PDF digitally. Provide pens and paper. No internet, external research, locks or special props are required. For groups, appoint a reader, timeline keeper and evidence reviewer; combine roles for smaller groups.

Suggested session
0-5 min: briefing and rules. 5-15 min: suspects. 15-30 min: evidence and recovery puzzle. 30-45 min: debate and worksheet. 45-60 min: hints if needed, reveal and discussion. These are suggested timings, not a mandatory timer.

Reveal procedure
Do not reveal the hiding place during setup. Once players submit an accusation, narrate finding the item at the location in the answer key. No physical search is required; the entire recovery is a paper puzzle.

Facilitation
Read only the written statements. Do not improvise extra alibis. If players propose credential theft or hidden conspirators, direct them to the operating rules. Let them challenge interpretations of evidence.

## Progressive hints

Hint 1 / direction
Separate motive from proof. Start with the exact incident window and the rules that make the access or camera record trustworthy.

Hint 2 / elimination
Compare all four statements against E1-E4. Locate the suspect whose claimed whereabouts or denied action cannot match the records. Check the other three people at that same time.

Hint 3 / recovery
Extract the capitals from: leaVe, wAit, hUsh, sLow, resT. Which storage area do they spell? Storage map: VAULT is the transport archive; other areas are LAB and OFFICE.
Work only with the supplied alphabet, key, fragments or directions; no external knowledge is required.

Hint 4 / strong hint
The record that directly connects Nadia Sol to the incident is decisive. The recovery answer is VAULT.

Hint policy
Offer hints one at a time and only on request. Hints 1-3 cost one point each. Hint 4 costs two points. Floor the final score at zero.

## Solution and evidence chain

Responsible person
Nadia Sol, gem conservator.

Method
Nadia opened the cabinet with her own two-factor credentials and carried the sapphire in a conservation tube.

Decisive chain
E1-E3 establish the relevant access, identity or timing. E4 adds corroboration or excludes another explanation. Compare these facts with the suspect statements; do not convict solely on motive.

Recovery answer
VAULT. The item is found at a padded tube in the transport archive vault.

Red herring explained
Leo caused the rehearsal blackout, but cabinet audit and continuous desk footage exclude him as the person who removed the stone.

Score / 10
2 points: correct person. 2: correct method. 2: two valid evidence references, one each. 2: correct recovery answer and location. 2: explain a red herring or eliminate an alternative. Subtract hint costs. 8-10: Case closed; 5-7: Strong lead; 0-4: Revisit the evidence.

Debrief
Which fact was necessary to your conclusion? Which suspect statement was unreliable? Why does motive alone fail to prove responsibility? All characters, events and institutions are fictional.
