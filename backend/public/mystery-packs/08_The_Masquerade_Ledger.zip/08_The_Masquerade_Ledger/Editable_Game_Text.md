# The Masquerade Ledger


## Case briefing

The Masquerade Ledger
A charity ledger proving donation fraud disappears during a Venetian masquerade. Masks obscure faces, but guest bracelets are uniquely numbered and stay sealed around each wrist. Recover the ledger before the auction.

Your mission
Identify the responsible person, explain the method and recover the missing item or recording. Cite at least two independent pieces of evidence.

Session details
Masked-ball intrigue | Ages 12+ | 1-6 investigators | 35-60 minutes | No graphic violence

Rules and preparation
Play cooperatively as investigators; suspects are case documents, not assigned player roles. Use a pen and paper. A host is optional. Keep Host Guide.pdf closed. Read this booklet in order. All evidence is truthful; suspect statements may be false. Do not invent accomplices, copied credentials or unseen events contrary to the stated rules.

## Suspect dossiers

Elena Voss, treasurer
Possible motive: The accounts expose her diverted donations.
Statement: "I stayed beside the donation desk."

Fabio Lane, violinist
Possible motive: The charity has not paid his fee.
Statement: "I performed the final waltz."

Gia Moretti, patron
Possible motive: She fears an embarrassing donation pledge.
Statement: "I remained on the balcony."

Hector Bell, event manager
Possible motive: Missing funds threaten his venue contract.
Statement: "I checked the auction stage."

## Evidence: access and timeline

Incident window
ledger taken at 22:06.

Operating rules
Sealed guest bracelets cannot be removed without cutting. Gate cameras read bracelet numbers, independent of costume or mask.

Evidence E1
22:05 bracelet 62 enters the records room; 22:07 it leaves holding a ledger-sized folio.

Evidence E2
Wrist registry: Elena 62; Fabio 26; Gia 41; Hector 83.

Evidence E3
Donation desk footage shows Elena absent from 22:03 to 22:09.

## Evidence: follow the trail

Evidence E4
Stage feed shows Fabio performing beside Hector at 22:06. Gia is visible on balcony footage.

Evidence E5
A folio tag gives shelf code as reversed text: NEERG.

Recovery puzzle
Reverse NEERG to identify the colour of the cloakroom shelf.

Investigation task
Compare statements to records. Which statement is contradicted? Which records exclude the other suspects? Solve the recovery clue before making an accusation. The recovery clue locates the item; it does not alone identify who hid it.

## Investigator worksheet

1 / Reconstruction
At the incident time, where was each suspect? Write a short timeline and attach evidence numbers.

2 / Contradiction
Quote the statement that conflicts with a reliable record. Explain why the record is reliable under the operating rules.

3 / Recovery
Puzzle answer: ______________________________
Expected recovery location: ______________________________

4 / Final accusation
Responsible person: ______________________________
Method: __________________________________________
Evidence one: ______________________________________
Evidence two: ______________________________________

5 / Alternative explanation
Name one suspicious fact that does not prove guilt. Explain why it does not overturn your conclusion.

Submit your solution
After everyone agrees, open the Host Guide. Award points using its rubric. You may revise your answer before reading the solution.

## Host setup and running order

Keep this file separate
SPOILERS. Give players only Player Booklet.pdf and the cover. In solo play, close this guide until you need a hint or wish to check your answer.

Before play
Print the five-page player booklet at 100% on A4, or share the PDF digitally. Provide pens and paper. No internet, external research, locks or special props are required. For groups, appoint a reader, timeline keeper and evidence reviewer; combine roles for smaller groups.

Suggested session
0-5 min: briefing and rules. 5-15 min: suspects. 15-30 min: evidence and recovery puzzle. 30-45 min: debate and worksheet. 45-60 min: hints if needed, reveal and discussion. These are suggested timings, not a mandatory timer.

Reveal procedure
Do not reveal the hiding place during setup. Once players submit an accusation, narrate finding the item at the location in the answer key. No physical search is required; the entire recovery is a paper puzzle.

Facilitation
Read only the written statements. Do not improvise extra alibis. If players propose credential theft or hidden conspirators, direct them to the operating rules. Let them challenge interpretations of evidence.

## Progressive hints

Hint 1 / direction
Separate motive from proof. Start with the exact incident window and the rules that make the access or camera record trustworthy.

Hint 2 / elimination
Compare all four statements against E1-E4. Locate the suspect whose claimed whereabouts or denied action cannot match the records. Check the other three people at that same time.

Hint 3 / recovery
Reverse NEERG to identify the colour of the cloakroom shelf.
Work only with the supplied alphabet, key, fragments or directions; no external knowledge is required.

Hint 4 / strong hint
The record that directly connects Elena Voss to the incident is decisive. The recovery answer is GREEN.

Hint policy
Offer hints one at a time and only on request. Hints 1-3 cost one point each. Hint 4 costs two points. Floor the final score at zero.

## Solution and evidence chain

Responsible person
Elena Voss, treasurer.

Method
Elena relied on matching masks to conceal her visit, overlooking the sealed bracelet gate record.

Decisive chain
E1-E3 establish the relevant access, identity or timing. E4 adds corroboration or excludes another explanation. Compare these facts with the suspect statements; do not convict solely on motive.

Recovery answer
GREEN. The item is found at a folio on the green cloakroom shelf.

Red herring explained
Gia concealed an embarrassing pledge, but her balcony footage and different bracelet exclude her from the records room.

Score / 10
2 points: correct person. 2: correct method. 2: two valid evidence references, one each. 2: correct recovery answer and location. 2: explain a red herring or eliminate an alternative. Subtract hint costs. 8-10: Case closed; 5-7: Strong lead; 0-4: Revisit the evidence.

Debrief
Which fact was necessary to your conclusion? Which suspect statement was unreliable? Why does motive alone fail to prove responsibility? All characters, events and institutions are fictional.
