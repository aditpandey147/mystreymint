# The Ghost Frequency


## Case briefing

The Ghost Frequency
A supposedly abandoned radio station transmits a ghostly warning every night. The town wants answers. Discover who schedules the broadcast and find the original recording.

Your mission
Identify the responsible person, explain the method and recover the missing item or recording. Cite at least two independent pieces of evidence.

Session details
Paranormal debunking | Ages 12+ | 1-6 investigators | 35-60 minutes | No graphic violence

Rules and preparation
Play cooperatively as investigators; suspects are case documents, not assigned player roles. Use a pen and paper. A host is optional. Keep Host Guide.pdf closed. Read this booklet in order. All evidence is truthful; suspect statements may be false. Do not invent accomplices, copied credentials or unseen events contrary to the stated rules.

## Suspect dossiers

Mina Fox, local historian
Possible motive: The mystery attracts visitors to her tours.
Statement: "I only researched the archive."

Noah Slate, sound technician
Possible motive: He wants to demonstrate his sound design.
Statement: "I tested the amplifier in the afternoon."

Orla Finch, property agent
Possible motive: A haunting could depress the building's purchase price.
Statement: "I have never used the station computer."

Theo Marsh, night guard
Possible motive: The activity may preserve his security job.
Statement: "I patrol outside at broadcast time."

## Evidence: access and timeline

Incident window
ghost audio scheduled at 16:42; transmitted automatically at 23:00.

Operating rules
Scheduling requires a personal hardware key and local fingerprint. Nighttime presence is unnecessary once a schedule is set.

Evidence E1
16:42 schedule created by hardware key OF and matching fingerprint.

Evidence E2
Registry: Mina MF; Noah NS; Orla OF; Theo TM.

Evidence E3
Hallway video shows Orla at the station computer at 16:42.

## Evidence: follow the trail

Evidence E4
The spectral voice is an old weather recording slowed to half speed. Noah's afternoon test ended at 15:10.

Evidence E5
Archive index uses Morse: dot dot dot / dash dash dash / dot dot dot. Key: S=three dots; O=three dashes.

Recovery puzzle
Use the supplied Morse key to decode the three groups. The recording drawers have three-letter labels.

Investigation task
Compare statements to records. Which statement is contradicted? Which records exclude the other suspects? Solve the recovery clue before making an accusation. The recovery clue locates the item; it does not alone identify who hid it.

## Investigator worksheet

1 / Reconstruction
At the incident time, where was each suspect? Write a short timeline and attach evidence numbers.

2 / Contradiction
Quote the statement that conflicts with a reliable record. Explain why the record is reliable under the operating rules.

3 / Recovery
Puzzle answer: ______________________________
Expected recovery location: ______________________________

4 / Final accusation
Responsible person: ______________________________
Method: __________________________________________
Evidence one: ______________________________________
Evidence two: ______________________________________

5 / Alternative explanation
Name one suspicious fact that does not prove guilt. Explain why it does not overturn your conclusion.

Submit your solution
After everyone agrees, open the Host Guide. Award points using its rubric. You may revise your answer before reading the solution.

## Host setup and running order

Keep this file separate
SPOILERS. Give players only Player Booklet.pdf and the cover. In solo play, close this guide until you need a hint or wish to check your answer.

Before play
Print the five-page player booklet at 100% on A4, or share the PDF digitally. Provide pens and paper. No internet, external research, locks or special props are required. For groups, appoint a reader, timeline keeper and evidence reviewer; combine roles for smaller groups.

Suggested session
0-5 min: briefing and rules. 5-15 min: suspects. 15-30 min: evidence and recovery puzzle. 30-45 min: debate and worksheet. 45-60 min: hints if needed, reveal and discussion. These are suggested timings, not a mandatory timer.

Reveal procedure
Do not reveal the hiding place during setup. Once players submit an accusation, narrate finding the item at the location in the answer key. No physical search is required; the entire recovery is a paper puzzle.

Facilitation
Read only the written statements. Do not improvise extra alibis. If players propose credential theft or hidden conspirators, direct them to the operating rules. Let them challenge interpretations of evidence.

## Progressive hints

Hint 1 / direction
Separate motive from proof. Start with the exact incident window and the rules that make the access or camera record trustworthy.

Hint 2 / elimination
Compare all four statements against E1-E4. Locate the suspect whose claimed whereabouts or denied action cannot match the records. Check the other three people at that same time.

Hint 3 / recovery
Use the supplied Morse key to decode the three groups. The recording drawers have three-letter labels.
Work only with the supplied alphabet, key, fragments or directions; no external knowledge is required.

Hint 4 / strong hint
The record that directly connects Orla Finch to the incident is decisive. The recovery answer is SOS.

Hint policy
Offer hints one at a time and only on request. Hints 1-3 cost one point each. Hint 4 costs two points. Floor the final score at zero.

## Solution and evidence chain

Responsible person
Orla Finch, property agent.

Method
Orla scheduled a slowed weather tape to make the property appear haunted and reduce its sale price.

Decisive chain
E1-E3 establish the relevant access, identity or timing. E4 adds corroboration or excludes another explanation. Compare these facts with the suspect statements; do not convict solely on motive.

Recovery answer
SOS. The item is found at original weather tape in drawer SOS.

Red herring explained
Theo's outdoor patrol at 23:00 is not an alibi for scheduling at 16:42. The credential and video evidence, rather than night presence, identify Orla.

Score / 10
2 points: correct person. 2: correct method. 2: two valid evidence references, one each. 2: correct recovery answer and location. 2: explain a red herring or eliminate an alternative. Subtract hint costs. 8-10: Case closed; 5-7: Strong lead; 0-4: Revisit the evidence.

Debrief
Which fact was necessary to your conclusion? Which suspect statement was unreliable? Why does motive alone fail to prove responsibility? All characters, events and institutions are fictional.
