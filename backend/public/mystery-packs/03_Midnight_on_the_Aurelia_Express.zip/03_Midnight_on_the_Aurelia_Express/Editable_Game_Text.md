# Midnight on the Aurelia Express


## Case briefing

Midnight on the Aurelia Express
A signed peace treaty disappears from a diplomatic case as the Aurelia Express crosses the mountain pass. The train will reach the border in an hour. Identify the thief and recover the document.

Your mission
Identify the responsible person, explain the method and recover the missing item or recording. Cite at least two independent pieces of evidence.

Session details
Railway mystery | Ages 12+ | 1-6 investigators | 35-60 minutes | No graphic violence

Rules and preparation
Play cooperatively as investigators; suspects are case documents, not assigned player roles. Use a pen and paper. A host is optional. Keep Host Guide.pdf closed. Read this booklet in order. All evidence is truthful; suspect statements may be false. Do not invent accomplices, copied credentials or unseen events contrary to the stated rules.

## Suspect dossiers

Ada Frost, interpreter
Possible motive: She wants to stop a corrupt land agreement.
Statement: "I was translating in the dining car."

Bruno Hale, porter
Possible motive: He has been promised money for train gossip.
Statement: "I delivered towels to compartment B."

Clara Wynn, journalist
Possible motive: An exclusive would rescue her newspaper.
Statement: "I photographed the mountain outside."

Dorian Moss, diplomat
Possible motive: The treaty exposes his secret side deal.
Statement: "I did not leave compartment A."

## Evidence: access and timeline

Incident window
case opened between 00:12 and 00:14.

Operating rules
Compartments A, B, C, D connect in a straight line. Dining car is beyond D. Corridor cameras cover every doorway and record coats and badges clearly.

Evidence E1
00:12 camera records Dorian leaving A with his diplomatic badge visible.

Evidence E2
00:13 Dorian enters B; 00:14 he leaves carrying a flat red document wallet.

Evidence E3
Porter inventory confirms Bruno delivered towels to B at 00:05 and returned to the dining car by 00:08.

## Evidence: follow the trail

Evidence E4
Ada, Bruno and Clara appear together on dining-car footage from 00:11 to 00:16.

Evidence E5
A torn luggage slip in B reads: treaty in locker; shift letters BACK ONE: D B T F.

Recovery puzzle
Shift each letter back one place in the alphabet: D B T F. The station lockers are labelled with words.

Investigation task
Compare statements to records. Which statement is contradicted? Which records exclude the other suspects? Solve the recovery clue before making an accusation. The recovery clue locates the item; it does not alone identify who hid it.

## Investigator worksheet

1 / Reconstruction
At the incident time, where was each suspect? Write a short timeline and attach evidence numbers.

2 / Contradiction
Quote the statement that conflicts with a reliable record. Explain why the record is reliable under the operating rules.

3 / Recovery
Puzzle answer: ______________________________
Expected recovery location: ______________________________

4 / Final accusation
Responsible person: ______________________________
Method: __________________________________________
Evidence one: ______________________________________
Evidence two: ______________________________________

5 / Alternative explanation
Name one suspicious fact that does not prove guilt. Explain why it does not overturn your conclusion.

Submit your solution
After everyone agrees, open the Host Guide. Award points using its rubric. You may revise your answer before reading the solution.

## Host setup and running order

Keep this file separate
SPOILERS. Give players only Player Booklet.pdf and the cover. In solo play, close this guide until you need a hint or wish to check your answer.

Before play
Print the five-page player booklet at 100% on A4, or share the PDF digitally. Provide pens and paper. No internet, external research, locks or special props are required. For groups, appoint a reader, timeline keeper and evidence reviewer; combine roles for smaller groups.

Suggested session
0-5 min: briefing and rules. 5-15 min: suspects. 15-30 min: evidence and recovery puzzle. 30-45 min: debate and worksheet. 45-60 min: hints if needed, reveal and discussion. These are suggested timings, not a mandatory timer.

Reveal procedure
Do not reveal the hiding place during setup. Once players submit an accusation, narrate finding the item at the location in the answer key. No physical search is required; the entire recovery is a paper puzzle.

Facilitation
Read only the written statements. Do not improvise extra alibis. If players propose credential theft or hidden conspirators, direct them to the operating rules. Let them challenge interpretations of evidence.

## Progressive hints

Hint 1 / direction
Separate motive from proof. Start with the exact incident window and the rules that make the access or camera record trustworthy.

Hint 2 / elimination
Compare all four statements against E1-E4. Locate the suspect whose claimed whereabouts or denied action cannot match the records. Check the other three people at that same time.

Hint 3 / recovery
Shift each letter back one place in the alphabet: D B T F. The station lockers are labelled with words.
Work only with the supplied alphabet, key, fragments or directions; no external knowledge is required.

Hint 4 / strong hint
The record that directly connects Dorian Moss to the incident is decisive. The recovery answer is CASE.

Hint policy
Offer hints one at a time and only on request. Hints 1-3 cost one point each. Hint 4 costs two points. Floor the final score at zero.

## Solution and evidence chain

Responsible person
Dorian Moss, diplomat.

Method
Dorian left A, opened the diplomatic case in B, and concealed the treaty before returning.

Decisive chain
E1-E3 establish the relevant access, identity or timing. E4 adds corroboration or excludes another explanation. Compare these facts with the suspect statements; do not convict solely on motive.

Recovery answer
CASE. The item is found at the onboard locker labelled CASE.

Red herring explained
Bruno had legitimate earlier access to B; the narrow theft window and dining-car video exclude him.

Score / 10
2 points: correct person. 2: correct method. 2: two valid evidence references, one each. 2: correct recovery answer and location. 2: explain a red herring or eliminate an alternative. Subtract hint costs. 8-10: Case closed; 5-7: Strong lead; 0-4: Revisit the evidence.

Debrief
Which fact was necessary to your conclusion? Which suspect statement was unreliable? Why does motive alone fail to prove responsibility? All characters, events and institutions are fictional.
