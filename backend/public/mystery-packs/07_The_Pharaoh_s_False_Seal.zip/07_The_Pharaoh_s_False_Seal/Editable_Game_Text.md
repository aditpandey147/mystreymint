# The Pharaoh's False Seal


## Case briefing

The Pharaoh's False Seal
At a desert dig, a newly catalogued scarab seal is replaced with a resin copy. The original must be found before the shipment leaves. Which team member performed the swap?

Your mission
Identify the responsible person, explain the method and recover the missing item or recording. Cite at least two independent pieces of evidence.

Session details
Archaeological forgery | Ages 12+ | 1-6 investigators | 35-60 minutes | No graphic violence

Rules and preparation
Play cooperatively as investigators; suspects are case documents, not assigned player roles. Use a pen and paper. A host is optional. Keep Host Guide.pdf closed. Read this booklet in order. All evidence is truthful; suspect statements may be false. Do not invent accomplices, copied credentials or unseen events contrary to the stated rules.

## Suspect dossiers

Amara Nabil, field director
Possible motive: A scandal could block excavation funding.
Statement: "I supervised the trench."

Basil Reed, photographer
Possible motive: He wants to sell a sensational discovery story.
Statement: "I photographed the north wall."

Cora Vale, conservator
Possible motive: She has been offered a private restoration commission.
Statement: "I checked resin samples in the lab."

Dev Malik, logistics lead
Possible motive: He can profit from an illicit collector shipment.
Statement: "I packed only empty supply crates."

## Evidence: access and timeline

Incident window
seal swapped at 11:32.

Operating rules
The object tray is sealed with a signed tamper strip. Inspection photographs show the genuine seal at 11:30 and the copy at 11:35.

Evidence E1
11:32 packing camera shows Dev breaking tray strip S8, replacing the object and resealing it with S9. His face and logistics badge are visible.

Evidence E2
Amara and Basil are together on trench footage at 11:30-11:36. Cora is visible on the lab feed.

Evidence E3
The resin copy carries a workshop batch mark, but the supply register records that all four team members could access that batch.

## Evidence: follow the trail

Evidence E4
Dev's shipment list adds one unusually heavy crate.

Evidence E5
Crate clue: arrange fragments by the printed numbers 1, 2, 3: (3)N; (1)SE; (2)VE.

Recovery puzzle
Join the fragments in numerical order, SE + VE + N.

Investigation task
Compare statements to records. Which statement is contradicted? Which records exclude the other suspects? Solve the recovery clue before making an accusation. The recovery clue locates the item; it does not alone identify who hid it.

## Investigator worksheet

1 / Reconstruction
At the incident time, where was each suspect? Write a short timeline and attach evidence numbers.

2 / Contradiction
Quote the statement that conflicts with a reliable record. Explain why the record is reliable under the operating rules.

3 / Recovery
Puzzle answer: ______________________________
Expected recovery location: ______________________________

4 / Final accusation
Responsible person: ______________________________
Method: __________________________________________
Evidence one: ______________________________________
Evidence two: ______________________________________

5 / Alternative explanation
Name one suspicious fact that does not prove guilt. Explain why it does not overturn your conclusion.

Submit your solution
After everyone agrees, open the Host Guide. Award points using its rubric. You may revise your answer before reading the solution.

## Host setup and running order

Keep this file separate
SPOILERS. Give players only Player Booklet.pdf and the cover. In solo play, close this guide until you need a hint or wish to check your answer.

Before play
Print the five-page player booklet at 100% on A4, or share the PDF digitally. Provide pens and paper. No internet, external research, locks or special props are required. For groups, appoint a reader, timeline keeper and evidence reviewer; combine roles for smaller groups.

Suggested session
0-5 min: briefing and rules. 5-15 min: suspects. 15-30 min: evidence and recovery puzzle. 30-45 min: debate and worksheet. 45-60 min: hints if needed, reveal and discussion. These are suggested timings, not a mandatory timer.

Reveal procedure
Do not reveal the hiding place during setup. Once players submit an accusation, narrate finding the item at the location in the answer key. No physical search is required; the entire recovery is a paper puzzle.

Facilitation
Read only the written statements. Do not improvise extra alibis. If players propose credential theft or hidden conspirators, direct them to the operating rules. Let them challenge interpretations of evidence.

## Progressive hints

Hint 1 / direction
Separate motive from proof. Start with the exact incident window and the rules that make the access or camera record trustworthy.

Hint 2 / elimination
Compare all four statements against E1-E4. Locate the suspect whose claimed whereabouts or denied action cannot match the records. Check the other three people at that same time.

Hint 3 / recovery
Join the fragments in numerical order, SE + VE + N.
Work only with the supplied alphabet, key, fragments or directions; no external knowledge is required.

Hint 4 / strong hint
The record that directly connects Dev Malik to the incident is decisive. The recovery answer is SEVEN.

Hint policy
Offer hints one at a time and only on request. Hints 1-3 cost one point each. Hint 4 costs two points. Floor the final score at zero.

## Solution and evidence chain

Responsible person
Dev Malik, logistics lead.

Method
Dev swapped the scarab for a readily available resin copy and packed the real seal into crate seven.

Decisive chain
E1-E3 establish the relevant access, identity or timing. E4 adds corroboration or excludes another explanation. Compare these facts with the suspect statements; do not convict solely on motive.

Recovery answer
SEVEN. The item is found at crate seven in the outgoing supply stack.

Red herring explained
Cora handled resin legitimately. The batch mark alone cannot distinguish any suspect; the timed packing video does.

Score / 10
2 points: correct person. 2: correct method. 2: two valid evidence references, one each. 2: correct recovery answer and location. 2: explain a red herring or eliminate an alternative. Subtract hint costs. 8-10: Case closed; 5-7: Strong lead; 0-4: Revisit the evidence.

Debrief
Which fact was necessary to your conclusion? Which suspect statement was unreliable? Why does motive alone fail to prove responsibility? All characters, events and institutions are fictional.
