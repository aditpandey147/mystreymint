# The Last Recipe at Ember House


## Case briefing

The Last Recipe at Ember House
The finale's handwritten signature recipe disappears from a locked preparation cabinet. A substitute page contains deliberately wrong quantities. Identify the saboteur and recover the authentic recipe before judging.

Your mission
Identify the responsible person, explain the method and recover the missing item or recording. Cite at least two independent pieces of evidence.

Session details
Culinary competition theft | Ages 12+ | 1-6 investigators | 35-60 minutes | No graphic violence

Rules and preparation
Play cooperatively as investigators; suspects are case documents, not assigned player roles. Use a pen and paper. A host is optional. Keep Host Guide.pdf closed. Read this booklet in order. All evidence is truthful; suspect statements may be false. Do not invent accomplices, copied credentials or unseen events contrary to the stated rules.

## Suspect dossiers

Anya Reed, finalist
Possible motive: She wants her rival disqualified.
Statement: "I stayed at station one."

Benoit Cross, judge
Possible motive: He wants to conceal a conflict of interest.
Statement: "I remained in the tasting room."

Cleo Hart, finalist
Possible motive: Her rival's recipe resembles her family's dish.
Statement: "I never opened the preparation cabinet."

Dante Wells, producer
Possible motive: A dramatic interruption would improve ratings.
Statement: "I worked from the control booth."

## Evidence: access and timeline

Incident window
recipe exchanged at 19:24.

Operating rules
Cabinet access uses a personal wrist tag plus fingerprint, with a mirrored audit in the control booth. Neither can be transferred.

Evidence E1
19:24 cabinet opens with tag CH and matching fingerprint.

Evidence E2
Registry: Anya AR; Benoit BC; Cleo CH; Dante DW.

Evidence E3
Overhead camera shows Cleo leaving station three at 19:22 and returning at 19:27 with a folded page.

## Evidence: follow the trail

Evidence E4
Anya, Benoit and Dante are continuously visible at their stated locations from 19:23 to 19:25.

Evidence E5
Recovered scrap: use the first letter of each ingredient: Rosemary, Anise, Cinnamon, Kosher salt.

Recovery puzzle
Read the first letters of Rosemary, Anise, Cinnamon, Kosher salt to name the hiding place.

Investigation task
Compare statements to records. Which statement is contradicted? Which records exclude the other suspects? Solve the recovery clue before making an accusation. The recovery clue locates the item; it does not alone identify who hid it.

## Investigator worksheet

1 / Reconstruction
At the incident time, where was each suspect? Write a short timeline and attach evidence numbers.

2 / Contradiction
Quote the statement that conflicts with a reliable record. Explain why the record is reliable under the operating rules.

3 / Recovery
Puzzle answer: ______________________________
Expected recovery location: ______________________________

4 / Final accusation
Responsible person: ______________________________
Method: __________________________________________
Evidence one: ______________________________________
Evidence two: ______________________________________

5 / Alternative explanation
Name one suspicious fact that does not prove guilt. Explain why it does not overturn your conclusion.

Submit your solution
After everyone agrees, open the Host Guide. Award points using its rubric. You may revise your answer before reading the solution.

## Host setup and running order

Keep this file separate
SPOILERS. Give players only Player Booklet.pdf and the cover. In solo play, close this guide until you need a hint or wish to check your answer.

Before play
Print the five-page player booklet at 100% on A4, or share the PDF digitally. Provide pens and paper. No internet, external research, locks or special props are required. For groups, appoint a reader, timeline keeper and evidence reviewer; combine roles for smaller groups.

Suggested session
0-5 min: briefing and rules. 5-15 min: suspects. 15-30 min: evidence and recovery puzzle. 30-45 min: debate and worksheet. 45-60 min: hints if needed, reveal and discussion. These are suggested timings, not a mandatory timer.

Reveal procedure
Do not reveal the hiding place during setup. Once players submit an accusation, narrate finding the item at the location in the answer key. No physical search is required; the entire recovery is a paper puzzle.

Facilitation
Read only the written statements. Do not improvise extra alibis. If players propose credential theft or hidden conspirators, direct them to the operating rules. Let them challenge interpretations of evidence.

## Progressive hints

Hint 1 / direction
Separate motive from proof. Start with the exact incident window and the rules that make the access or camera record trustworthy.

Hint 2 / elimination
Compare all four statements against E1-E4. Locate the suspect whose claimed whereabouts or denied action cannot match the records. Check the other three people at that same time.

Hint 3 / recovery
Read the first letters of Rosemary, Anise, Cinnamon, Kosher salt to name the hiding place.
Work only with the supplied alphabet, key, fragments or directions; no external knowledge is required.

Hint 4 / strong hint
The record that directly connects Cleo Hart to the incident is decisive. The recovery answer is RACK.

Hint policy
Offer hints one at a time and only on request. Hints 1-3 cost one point each. Hint 4 costs two points. Floor the final score at zero.

## Solution and evidence chain

Responsible person
Cleo Hart, finalist.

Method
Cleo replaced the authentic recipe with a sabotaged copy, then hid the original behind her spice rack.

Decisive chain
E1-E3 establish the relevant access, identity or timing. E4 adds corroboration or excludes another explanation. Compare these facts with the suspect statements; do not convict solely on motive.

Recovery answer
RACK. The item is found at behind the spice rack at station three.

Red herring explained
Dante wanted drama, but motivation alone is insufficient; the two-factor cabinet log and camera identify Cleo.

Score / 10
2 points: correct person. 2: correct method. 2: two valid evidence references, one each. 2: correct recovery answer and location. 2: explain a red herring or eliminate an alternative. Subtract hint costs. 8-10: Case closed; 5-7: Strong lead; 0-4: Revisit the evidence.

Debrief
Which fact was necessary to your conclusion? Which suspect statement was unreliable? Why does motive alone fail to prove responsibility? All characters, events and institutions are fictional.
