# The Last Bell at Blackthorn Manor


## Case briefing

The Last Bell at Blackthorn Manor
At the midnight reading of Lady Blackthorn's will, her original testament disappears from the locked study. A bell rings from the deserted west wing. Recover the will and identify who staged the haunting.

Your mission
Identify the responsible person, explain the method and recover the missing item or recording. Cite at least two independent pieces of evidence.

Session details
Gothic theft | Ages 12+ | 1-6 investigators | 35-60 minutes | No graphic violence

Rules and preparation
Play cooperatively as investigators; suspects are case documents, not assigned player roles. Use a pen and paper. A host is optional. Keep Host Guide.pdf closed. Read this booklet in order. All evidence is truthful; suspect statements may be false. Do not invent accomplices, copied credentials or unseen events contrary to the stated rules.

## Suspect dossiers

Mara Vale, estate secretary
Possible motive: An audit would expose diverted estate payments.
Statement: "I filed papers in the study until 23:48, then left for the kitchen."

Elias Reed, bell restorer
Possible motive: His restoration invoice remains unpaid.
Statement: "I repaired the west bell until 23:40."

Celia Blackthorn, niece
Possible motive: The new will reduces her inheritance.
Statement: "I stayed in the drawing room from 23:45."

Owen Pike, groundskeeper
Possible motive: The estate sale threatens his cottage.
Statement: "I checked the greenhouse after 23:40."

## Evidence: access and timeline

Incident window
will removed at 23:52.

Operating rules
Study lock accepts numbered staff tokens; tokens cannot be copied or lent during the sealed inventory.

Evidence E1
23:51 token 17 entered the study; 23:54 token 17 left.

Evidence E2
Token ledger: Mara 17; Elias 24; Celia 31; Owen 46.

Evidence E3
Kitchen camera shows Mara arriving at 23:57. Celia is visible in the drawing room at 23:52.

## Evidence: follow the trail

Evidence E4
West bell timer was set at 23:35 to ring at midnight. Elias completed that repair under supervision.

Evidence E5
A carbon impression in the study reads: WILL TO ARCHIVE DRAWER.

Recovery puzzle
Decode the archive label: 4-18-1-23-5-18. Use A=1 through Z=26.

Investigation task
Compare statements to records. Which statement is contradicted? Which records exclude the other suspects? Solve the recovery clue before making an accusation. The recovery clue locates the item; it does not alone identify who hid it.

## Investigator worksheet

1 / Reconstruction
At the incident time, where was each suspect? Write a short timeline and attach evidence numbers.

2 / Contradiction
Quote the statement that conflicts with a reliable record. Explain why the record is reliable under the operating rules.

3 / Recovery
Puzzle answer: ______________________________
Expected recovery location: ______________________________

4 / Final accusation
Responsible person: ______________________________
Method: __________________________________________
Evidence one: ______________________________________
Evidence two: ______________________________________

5 / Alternative explanation
Name one suspicious fact that does not prove guilt. Explain why it does not overturn your conclusion.

Submit your solution
After everyone agrees, open the Host Guide. Award points using its rubric. You may revise your answer before reading the solution.

## Host setup and running order

Keep this file separate
SPOILERS. Give players only Player Booklet.pdf and the cover. In solo play, close this guide until you need a hint or wish to check your answer.

Before play
Print the five-page player booklet at 100% on A4, or share the PDF digitally. Provide pens and paper. No internet, external research, locks or special props are required. For groups, appoint a reader, timeline keeper and evidence reviewer; combine roles for smaller groups.

Suggested session
0-5 min: briefing and rules. 5-15 min: suspects. 15-30 min: evidence and recovery puzzle. 30-45 min: debate and worksheet. 45-60 min: hints if needed, reveal and discussion. These are suggested timings, not a mandatory timer.

Reveal procedure
Do not reveal the hiding place during setup. Once players submit an accusation, narrate finding the item at the location in the answer key. No physical search is required; the entire recovery is a paper puzzle.

Facilitation
Read only the written statements. Do not improvise extra alibis. If players propose credential theft or hidden conspirators, direct them to the operating rules. Let them challenge interpretations of evidence.

## Progressive hints

Hint 1 / direction
Separate motive from proof. Start with the exact incident window and the rules that make the access or camera record trustworthy.

Hint 2 / elimination
Compare all four statements against E1-E4. Locate the suspect whose claimed whereabouts or denied action cannot match the records. Check the other three people at that same time.

Hint 3 / recovery
Decode the archive label: 4-18-1-23-5-18. Use A=1 through Z=26.
Work only with the supplied alphabet, key, fragments or directions; no external knowledge is required.

Hint 4 / strong hint
The record that directly connects Mara Vale to the incident is decisive. The recovery answer is DRAWER.

Hint policy
Offer hints one at a time and only on request. Hints 1-3 cost one point each. Hint 4 costs two points. Floor the final score at zero.

## Solution and evidence chain

Responsible person
Mara Vale, estate secretary.

Method
Mara used her assigned token to remove the will, then exploited the scheduled bell to suggest a supernatural intruder.

Decisive chain
E1-E3 establish the relevant access, identity or timing. E4 adds corroboration or excludes another explanation. Compare these facts with the suspect statements; do not convict solely on motive.

Recovery answer
DRAWER. The item is found at the archive drawer.

Red herring explained
Elias really set the bell timer as part of his documented repair; that explains the sound without placing him at the theft.

Score / 10
2 points: correct person. 2: correct method. 2: two valid evidence references, one each. 2: correct recovery answer and location. 2: explain a red herring or eliminate an alternative. Subtract hint costs. 8-10: Case closed; 5-7: Strong lead; 0-4: Revisit the evidence.

Debrief
Which fact was necessary to your conclusion? Which suspect statement was unreliable? Why does motive alone fail to prove responsibility? All characters, events and institutions are fictional.
