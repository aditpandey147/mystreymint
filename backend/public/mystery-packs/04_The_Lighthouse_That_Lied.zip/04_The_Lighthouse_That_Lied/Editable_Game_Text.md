# The Lighthouse That Lied


## Case briefing

The Lighthouse That Lied
A false red signal sends a supply boat toward a closed channel. The captain turns away in time. Someone altered the lighthouse signal controller. Determine who did it and locate the removed green lens.

Your mission
Identify the responsible person, explain the method and recover the missing item or recording. Cite at least two independent pieces of evidence.

Session details
Coastal sabotage | Ages 12+ | 1-6 investigators | 35-60 minutes | No graphic violence

Rules and preparation
Play cooperatively as investigators; suspects are case documents, not assigned player roles. Use a pen and paper. A host is optional. Keep Host Guide.pdf closed. Read this booklet in order. All evidence is truthful; suspect statements may be false. Do not invent accomplices, copied credentials or unseen events contrary to the stated rules.

## Suspect dossiers

Nell Price, keeper
Possible motive: She fears losing the historic lighthouse.
Statement: "I stayed in the lantern room."

Tomas Venn, electrician
Possible motive: A failed signal could win him a repair contract.
Statement: "I only inspected the generator."

Rhea Cole, harbour broker
Possible motive: A delayed boat benefits her rival shipping deal.
Statement: "I never entered the controller room."

Samir Ash, weather observer
Possible motive: He wants attention for ignored storm warnings.
Statement: "I was recording wind on the roof."

## Evidence: access and timeline

Incident window
controller changed at 18:22.

Operating rules
Controller records signed service keys; the keys are physically tethered to each wearer throughout the inspection.

Evidence E1
18:22 signal changed from green to red using service key RV.

Evidence E2
Inspection roster: Nell NP; Tomas TV; Rhea RV; Samir SA.

Evidence E3
A corridor photograph shows Rhea beside the controller at 18:21.

## Evidence: follow the trail

Evidence E4
Generator video shows Tomas from 18:18 to 18:27. Roof and lantern logs place Samir and Nell away from the controller.

Evidence E5
Lens storage uses bearings: N=1, E=2, S=3, W=4. Service note lists E, W, N.

Recovery puzzle
Convert E, W, N using the supplied bearing key to find the three-digit locker.

Investigation task
Compare statements to records. Which statement is contradicted? Which records exclude the other suspects? Solve the recovery clue before making an accusation. The recovery clue locates the item; it does not alone identify who hid it.

## Investigator worksheet

1 / Reconstruction
At the incident time, where was each suspect? Write a short timeline and attach evidence numbers.

2 / Contradiction
Quote the statement that conflicts with a reliable record. Explain why the record is reliable under the operating rules.

3 / Recovery
Puzzle answer: ______________________________
Expected recovery location: ______________________________

4 / Final accusation
Responsible person: ______________________________
Method: __________________________________________
Evidence one: ______________________________________
Evidence two: ______________________________________

5 / Alternative explanation
Name one suspicious fact that does not prove guilt. Explain why it does not overturn your conclusion.

Submit your solution
After everyone agrees, open the Host Guide. Award points using its rubric. You may revise your answer before reading the solution.

## Host setup and running order

Keep this file separate
SPOILERS. Give players only Player Booklet.pdf and the cover. In solo play, close this guide until you need a hint or wish to check your answer.

Before play
Print the five-page player booklet at 100% on A4, or share the PDF digitally. Provide pens and paper. No internet, external research, locks or special props are required. For groups, appoint a reader, timeline keeper and evidence reviewer; combine roles for smaller groups.

Suggested session
0-5 min: briefing and rules. 5-15 min: suspects. 15-30 min: evidence and recovery puzzle. 30-45 min: debate and worksheet. 45-60 min: hints if needed, reveal and discussion. These are suggested timings, not a mandatory timer.

Reveal procedure
Do not reveal the hiding place during setup. Once players submit an accusation, narrate finding the item at the location in the answer key. No physical search is required; the entire recovery is a paper puzzle.

Facilitation
Read only the written statements. Do not improvise extra alibis. If players propose credential theft or hidden conspirators, direct them to the operating rules. Let them challenge interpretations of evidence.

## Progressive hints

Hint 1 / direction
Separate motive from proof. Start with the exact incident window and the rules that make the access or camera record trustworthy.

Hint 2 / elimination
Compare all four statements against E1-E4. Locate the suspect whose claimed whereabouts or denied action cannot match the records. Check the other three people at that same time.

Hint 3 / recovery
Convert E, W, N using the supplied bearing key to find the three-digit locker.
Work only with the supplied alphabet, key, fragments or directions; no external knowledge is required.

Hint 4 / strong hint
The record that directly connects Rhea Cole to the incident is decisive. The recovery answer is 241.

Hint policy
Offer hints one at a time and only on request. Hints 1-3 cost one point each. Hint 4 costs two points. Floor the final score at zero.

## Solution and evidence chain

Responsible person
Rhea Cole, harbour broker.

Method
Rhea used her inspection key to change the signal and hid the green lens to delay restoration.

Decisive chain
E1-E3 establish the relevant access, identity or timing. E4 adds corroboration or excludes another explanation. Compare these facts with the suspect statements; do not convict solely on motive.

Recovery answer
241. The item is found at locker 241 in the maintenance shed.

Red herring explained
Tomas benefits from a fault, but continuous generator video excludes his operating the controller.

Score / 10
2 points: correct person. 2: correct method. 2: two valid evidence references, one each. 2: correct recovery answer and location. 2: explain a red herring or eliminate an alternative. Subtract hint costs. 8-10: Case closed; 5-7: Strong lead; 0-4: Revisit the evidence.

Debrief
Which fact was necessary to your conclusion? Which suspect statement was unreliable? Why does motive alone fail to prove responsibility? All characters, events and institutions are fictional.
